<?php

class Lovat_Interfacing_Model_Order
{

}