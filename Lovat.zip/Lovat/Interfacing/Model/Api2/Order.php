<?php

class Lovat_Interfacing_Model_Api2_Order extends Mage_Api2_Model_Resource
{

}