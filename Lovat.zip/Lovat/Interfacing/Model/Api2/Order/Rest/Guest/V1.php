<?php

class Lovat_Interfacing_Model_Api2_Order_Rest_Guest_V1 extends Lovat_Interfacing_Model_Api2_Order_Rest
{

}